package view;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import model.OrderHeader;
import model.User;

public class AdminAssignOrderToCourierPage {

	private Scene scene;
	private BorderPane bp;
	private Label titleLbl, idOrderLbl, idCustomerLbl, idPromoLbl, statusLbl, orderAtLbl, totalAmountLbl, resultLbl;
	private Button backBtn, updateBtn;
	private User currentUser;
	private GridPane gp;
	private OrderHeader orderHeader;
	private TextField idOrderTf, idCustomerTf, idPromoTf, statusTf, orderAtTf, totalAmountTf;
	
	private TableView<OrderHeader> orderHeaderTV;

    public AdminAssignOrderToCourierPage(User user) {
        this.currentUser = user;
        init();
        layout();
    }

	void init() {
		bp = new BorderPane();
		gp = new GridPane();
		titleLbl = new Label("Assign Order To Courier");
		
		bp.setTop(titleLbl);
		
		orderHeaderTV = new TableView<>();
		setUpTable();
		
		bp.setCenter(orderHeaderTV);
		
		idOrderLbl = new Label("Order Id:");
		idCustomerLbl = new Label("Customer Id:");
		idPromoLbl = new Label("Promo Id:");
		statusLbl = new Label("Status:");
		orderAtLbl = new Label("Date:");
		totalAmountLbl = new Label("Total Amout:");
		resultLbl = new Label("");
		
		idOrderTf = new TextField();
		idCustomerTf = new TextField();
		idPromoTf = new TextField();
		statusTf = new TextField();
		orderAtTf = new TextField();
		totalAmountTf = new TextField();
		
		updateBtn = new Button("Update");
		backBtn = new Button("Back to Menu");
		
		scene = new Scene(bp, 600, 600);
	}
	
//	@SuppressWarnings("unchecked")
	void setUpTable() {
		TableColumn<OrderHeader, String> idOrCol = new TableColumn<OrderHeader, String>("Order Id");
		idOrCol.setCellValueFactory(new PropertyValueFactory<OrderHeader, String>("orderID"));
		
		TableColumn<OrderHeader, String> idCusCol = new TableColumn<OrderHeader, String>("Customer Id");
		idCusCol.setCellValueFactory(new PropertyValueFactory<OrderHeader, String>("customerID"));
		
		TableColumn<OrderHeader, String> idProCol = new TableColumn<OrderHeader, String>("promo Id");
		idProCol.setCellValueFactory(new PropertyValueFactory<OrderHeader, String>("promoID"));
		
		TableColumn<OrderHeader, Double> totAmoCol = new TableColumn<OrderHeader, Double>("Total Amount");
		totAmoCol.setCellValueFactory(new PropertyValueFactory<OrderHeader, Double>("totalAmount"));
		
		TableColumn<OrderHeader, Double> orDaCol = new TableColumn<OrderHeader, Double>("Order Date");
		orDaCol.setCellValueFactory(new PropertyValueFactory<OrderHeader, Double>("orderDate"));
		
		TableColumn<OrderHeader, String> staCol = new TableColumn<OrderHeader, String>("Status");
		staCol.setCellValueFactory(new PropertyValueFactory<OrderHeader, String>("status"));
		
		orderHeaderTV.getColumns().addAll(idOrCol, idCusCol, idProCol, totAmoCol, orDaCol, staCol);
	}
	
	void layout() {
		titleLbl.setPadding(new Insets(10, 5, 10, 5));
		BorderPane.setAlignment(titleLbl, Pos.CENTER);
		titleLbl.setFont(Font.font("Cambria", FontWeight.BOLD, 30));
		
		updateBtn.setStyle("-fx-background-color: green; -fx-text-fill: white; -fx-font-weight: bold;");
		backBtn.setStyle("-fx-background-color: blue; -fx-text-fill: white; -fx-font-weight: bold;");
		
		gp.add(idOrderLbl, 0, 1);
		gp.add(idCustomerLbl, 0, 2);
		gp.add(idPromoLbl, 0, 3);
		gp.add(statusLbl, 0, 4);
		gp.add(orderAtLbl, 0, 5);
		gp.add(totalAmountLbl, 0, 6);
		
		gp.add(idOrderTf, 1, 1);
		gp.add(idCustomerTf, 1, 2);
		gp.add(idPromoTf, 1, 3);
		gp.add(statusTf, 1, 4);
		gp.add(orderAtTf, 1, 5);
		gp.add(totalAmountTf, 1, 6);
		
		gp.add(updateBtn, 0, 7);
		gp.add(resultLbl, 1, 7);
		gp.add(backBtn, 0, 8);
		bp.setBottom(gp);
	}

    public Scene getScene() { return scene; }
    public Button getBackBtn() { return backBtn; }
    public Button getUpdateBtn() { return updateBtn; }
    public User getCurrentUser() { return currentUser; }
    public TextField getIdOrderTf() { return idOrderTf; }
    public TextField getIdCustomerTf() { return idCustomerTf; }
    public TextField getIdPromoTf() { return idPromoTf; }
    public TextField getStatusTf() { return statusTf; }
    public TextField getOrderAtTf() { return orderAtTf; }
    public TextField getTotalAmountTf() { return totalAmountTf; }
    public void setResultLbl(Label Label) { this.resultLbl = Label; }
}