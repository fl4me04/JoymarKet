package view;

import java.util.ArrayList;

import controller.CartItemHandler;
import controller.UserHandler;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.geometry.VPos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonBase;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import model.CartItem;
import model.User;

public class CheckoutPage {
	
	private Scene scene;
	private BorderPane bp;
	private Label titleLbl, promoLbl, balanceLbl, balanceResultLbl, promoResultLbl;
	private Button backBtn, checkBtn, checkoutBtn;
	private User currentUser;
	private GridPane gp;
	private TextField promoTf;
	private CartItemHandler cartItemHandler;
	private UserHandler userHandler;
	
	private TableView<CartItem> cartItem;
	
	void init() {
		bp = new BorderPane();
		gp = new GridPane();
		titleLbl = new Label("Customer Checkout");
		
		bp.setTop(titleLbl);
		
		cartItem = new TableView<>();
//		setUpTable();
		
		bp.setCenter(cartItem);
		
		balanceLbl = new Label("Your Balance: ");
		
		balanceResultLbl = new Label("");
//		setBalance(this.currentUser);
		
		promoResultLbl = new Label("");
		
		backBtn = new Button("Back to Menu");
		checkoutBtn = new Button("Checkout!");
	
		promoLbl = new Label("Masukkan Promo: ");
		promoTf = new TextField();
		
		checkBtn = new Button("Check Promo!");
		
		scene = new Scene(bp, 600, 600);
	}
	
//	@SuppressWarnings("unchecked")
	void setUpTable() {
		TableColumn<CartItem, String> idCusCol = new TableColumn<CartItem, String>("Customer Id");
		idCusCol.setCellValueFactory(new PropertyValueFactory<CartItem, String>("idCustomer"));
		
		TableColumn<CartItem, String> idProCol = new TableColumn<CartItem, String>("Product Id");
		idProCol.setCellValueFactory(new PropertyValueFactory<CartItem, String>("idProduct"));
		
		TableColumn<CartItem, Integer> countCol = new TableColumn<CartItem, Integer>("Count");
		countCol.setCellValueFactory(new PropertyValueFactory<CartItem, Integer>("count"));
		
		cartItem.getColumns().addAll(idCusCol, idProCol, countCol);
	}
	
	void layout() {
		titleLbl.setPadding(new Insets(10, 5, 10, 5));
		BorderPane.setAlignment(titleLbl, Pos.CENTER);
		titleLbl.setFont(Font.font("Cambria", FontWeight.BOLD, 30));
		
		checkoutBtn.setStyle("-fx-background-color: green; -fx-text-fill: white; -fx-font-weight: bold;");
		backBtn.setStyle("-fx-background-color: blue; -fx-text-fill: white; -fx-font-weight: bold;");
		
		gp.add(balanceLbl, 0, 0);
		gp.add(balanceResultLbl, 1, 0);
		gp.add(promoLbl, 0, 1);
		gp.add(promoTf, 2, 1);
		gp.add(checkBtn, 3, 1);
		gp.add(promoResultLbl, 4, 1);
		gp.add(checkoutBtn, 0, 2);
		gp.add(backBtn, 0, 3);
		bp.setBottom(gp);
	}
	
	void loadTableData(String userId) {
        ArrayList<CartItem> userList = cartItemHandler.getAllItem(userId);
        
        if (userList != null && !userList.isEmpty()) {
        	cartItem.getItems().addAll(userList);
        } else {
            // Jika data kosong, tampilkan pesan
            Label emptyMsg = new Label("Tidak ada data pengguna yang tersedia.");
            emptyMsg.setFont(Font.font("Arial", FontWeight.NORMAL, 16));
            bp.setCenter(new VBox(emptyMsg));
        }
    }
	
	private void setBalance(User user) {
		double result = userHandler.getBalance(user.getIdUser());
		balanceResultLbl.setText(String.valueOf(result));
	}
	
	public CheckoutPage(User user) {
		this.currentUser = user;
		init();
		layout();
//		loadTableData(user.getIdUser());
	}

	public Scene getScene() {
		return this.scene;
	}
	
	public void refreshList(ArrayList<CartItem> listCart) {
		cartItem.getItems().clear();
		cartItem.getItems().addAll(listCart);
	}
	
    public Button getBackBtn() { return backBtn; }
    public TextField getPromoTf() { return promoTf; }
    public void setPromoResultLbl(Label promoResult) { this.promoResultLbl = promoResult; }
    public Button getCheckBtn() { return checkBtn; }
    public Button getCheckoutBtn() { return checkoutBtn; }
    public User getCurrentUser() { return currentUser; }
}
