package model;

public class Promo {
	protected String promoId;
	protected String code;
	protected String headline;
	protected Double discountPercentage;
	
	public Promo(String promoId, String code, String headline, Double discountPercentage) {
		super();
		this.promoId = promoId;
		this.code = code;
		this.headline = headline;
		this.discountPercentage = discountPercentage;
	}

	public String getPromoId() {
		return promoId;
	}

	public void setPromoId(String promoId) {
		this.promoId = promoId;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getHeadline() {
		return headline;
	}

	public void setHeadline(String headline) {
		this.headline = headline;
	}

	public Double getDiscountPercentage() {
		return discountPercentage;
	}

	public void setDiscountPercentage(Double discountPercentage) {
		this.discountPercentage = discountPercentage;
	}
	
	

}
