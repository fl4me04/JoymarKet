package model;

import java.time.LocalDateTime;

public class OrderHeader {

	protected String orderID;
	protected String customerID;
	protected String promoID;
	protected double totalAmount;
	protected LocalDateTime orderLocalDateTime;
	protected String status;
	
	
	public OrderHeader(String orderID, String customerID, String promoID, double totalAmount, LocalDateTime orderLocalDateTime, String status) {
		super();
		this.orderID = orderID;
		this.customerID = customerID;
		this.promoID = promoID;
		this.totalAmount = totalAmount;
		this.orderLocalDateTime = orderLocalDateTime;
		this.status = status;
	}


	public String getOrderID() {
		return orderID;
	}


	public void setOrderID(String orderID) {
		this.orderID = orderID;
	}


	public String getCustomerID() {
		return customerID;
	}


	public void setCustomerID(String customerID) {
		this.customerID = customerID;
	}


	public String getPromoID() {
		return promoID;
	}


	public void setPromoID(String promoID) {
		this.promoID = promoID;
	}


	public double getTotalAmount() {
		return totalAmount;
	}


	public void setTotalAmount(double totalAmount) {
		this.totalAmount = totalAmount;
	}


	public LocalDateTime getOrderLocalDateTime() {
		return orderLocalDateTime;
	}


	public void setOrderLocalDateTime(LocalDateTime orderLocalDateTime) {
		this.orderLocalDateTime = orderLocalDateTime;
	}


	public String getstatus() {
		return status;
	}


	public void setstatus(String status) {
		this.status = status;
	}
	
	
}
