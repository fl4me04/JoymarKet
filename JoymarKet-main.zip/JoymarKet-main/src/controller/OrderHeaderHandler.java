package controller;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.Date;
import database.Connect;

public class OrderHeaderHandler {

	public boolean addNewOrderHeader(String customerID, String promoID, double totalAmount, LocalDateTime orderDate, String status) {
		String query = "INSERT INTO orderheader (customerID, promoID, totalAmount, orderDate, status) VALUES (?, ?, ?, ?, ?)";
		Timestamp sqlTimestamp = Timestamp.valueOf(orderDate);
		
        try {
            PreparedStatement ps = Connect.getInstance().prepareStatement(query);
            ps.setString(1, customerID);
            ps.setString(2, promoID);
            ps.setDouble(3, totalAmount);
            ps.setTimestamp(4, sqlTimestamp);
            ps.setString(5, status);
            
            int result = ps.executeUpdate();
            return result > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
	}
	
	public boolean editOrderHeader(String orderID, String customerID, String promoID, double totalAmount, LocalDateTime orderLocalDateTime, String status) {
	    String query = "UPDATE orderheader SET customerID =?, promoID=?, totalAmount=?, orderDate=?, status=? WHERE orderID=?";
	    Timestamp sqlTimestamp = Timestamp.valueOf(orderLocalDateTime);
	    
	    try {
	        PreparedStatement ps = Connect.getInstance().prepareStatement(query);
	        ps.setString(1, orderID);
	        ps.setString(2, customerID);
	        ps.setString(3, promoID);
	        ps.setDouble(4, totalAmount);
	        ps.setTimestamp(4, sqlTimestamp);
	        ps.setString(6, status);
	        ps.setString(7, orderID);
	        return ps.executeUpdate() > 0;
	    } catch (SQLException e) {
	        e.printStackTrace();
	        return false;
	    }
	}
}
