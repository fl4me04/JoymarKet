package controller;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.util.ArrayList;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Label;
import javafx.stage.Stage;
import model.Admin;
import model.CartItem;
import model.Customer;
import model.Product;
import model.Promo;
import model.User;
import database.Connect;
import view.CheckoutPage;
import view.MenuPage;
import view.ProfilePage;

public class CheckoutController {

	private CheckoutPage view;
	private Stage stage;
	private CartItem cartItem;
	private User currentUser;
	private CartItemHandler cartItemHandler;
	private PromoHandler promoHandler;
	private OrderHeaderHandler orderHeaderHandler;
	private Promo promo;
	private Product product;
	LocalDateTime now = LocalDateTime.now();
	
	public CheckoutController(CheckoutPage view, Stage stage) {
        this.view = view;
        this.stage = stage;
        initializeTriggers();
    }

	private void initializeTriggers() {
        view.getBackBtn().setOnAction(e -> {
            navigateToMenu(view.getCurrentUser());
        });
        
        view.getCheckBtn().setOnAction(e -> {
        	showResultPromo();
        });
        
        view.getCheckoutBtn().setOnAction(e -> {
        	makeOrderHeader();
        });
    }
    
    private void makeOrderHeader() {
    	String code = view.getPromoTf().getText();
    	boolean isPromo = promoHandler.isPromo(code);
    	promo = promoHandler.getPromo(code);
    	
    	if (isPromo) {
    		boolean success = orderHeaderHandler.addNewOrderHeader(currentUser.getIdUser(), promo.getPromoId(), (cartItem.getCount() * product.getPrice()) * promo.getDiscountPercentage(), now, "Not Delivered");
    	} else {
    		boolean success = orderHeaderHandler.addNewOrderHeader(currentUser.getIdUser(), promo.getPromoId(), (cartItem.getCount() * product.getPrice()) * 1, now, "Not Delivered");
    	}
	}

	private void showResultPromo() {
    	String code = view.getPromoTf().getText();
    	
    	boolean isPromo = promoHandler.isPromo(code);
    	
    	if (isPromo) {
    		Label result = new Label("Promo Berhasil Digunakan!");
    		view.setPromoResultLbl(result);
    	} else {
    		Label result = new Label("Promo Tidak Valid!");
    		view.setPromoResultLbl(result);
    	}
    }
    

    private void navigateToMenu(User user) {
        try {
            MenuPage menuPage = new MenuPage(user);
            new MenuController(menuPage, stage);
            stage.setScene(menuPage.getScene());
            stage.setTitle("Main Menu");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
