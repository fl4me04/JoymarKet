package controller;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Label;
import javafx.stage.Stage;
import model.User;
import view.AdminAssignOrderToCourierPage;
import view.MenuPage;
import view.ProfilePage;

public class AdminAssignOrderToCourierController {

	private AdminAssignOrderToCourierPage view;
	private Stage stage;
	private OrderHeaderHandler orderHeaderHandler;

	public AdminAssignOrderToCourierController (AdminAssignOrderToCourierPage view, Stage stage) {
        this.view = view;
        this.stage = stage;
//        this.userHandler = new UserHandler();
        initializeTriggers();
    }

    private void initializeTriggers() {
        view.getBackBtn().setOnAction(e -> {
            navigateToMenu(view.getCurrentUser());
        });
        
        view.getUpdateBtn().setOnAction(e -> {
            navigateToUpdate();
        });
    }

    private void navigateToUpdate() {
    	String totalAmountString = view.getTotalAmountTf().getText();
    	String dateTimeString = view.getOrderAtTf().getText(); 
    	DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss");
    	
    	String orderID = view.getIdOrderTf().getText();
    	String customerID = view.getIdCustomerTf().getText();
    	String promoID = view.getIdPromoTf().getText();
    	double totalAmount = Double.parseDouble(totalAmountString);
    	LocalDateTime orderLocalDateTime = LocalDateTime.parse(dateTimeString, formatter);
    	String status = view.getIdOrderTf().getText();
    	
    	boolean success = orderHeaderHandler.editOrderHeader(orderID, customerID, promoID, totalAmount, orderLocalDateTime, status);
    	
    	if (success) {
    		Label label = new Label("Berhasil Update!");
    		view.setResultLbl(label);
    	} else {
    		Label label = new Label("Gagal Update!");
    		view.setResultLbl(label);
    	}
	}

	private void navigateToMenu(User user) {
        try {
            MenuPage menuPage = new MenuPage(user);
            new MenuController(menuPage, stage);
            stage.setScene(menuPage.getScene());
            stage.setTitle("Main Menu");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


}
