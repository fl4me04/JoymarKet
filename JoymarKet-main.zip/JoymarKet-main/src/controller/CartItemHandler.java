package controller;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import database.Connect;
import model.Admin;
import model.CartItem;
import model.Customer;

public class CartItemHandler {

	public ArrayList<CartItem> getAllItem(String idUser) {
		ArrayList<CartItem> listCart= new ArrayList<>();
		String query = "SELECT * FROM cartitem WHERE customerID = ?";
	    
	    try {
	        PreparedStatement ps = Connect.getInstance().prepareStatement(query);
	        ps.setString(1, idUser);
	        ResultSet rs = ps.executeQuery();
	        
	        while (rs.next()) {
	            String idProduct = rs.getString("productID");
	            int count = rs.getInt("count");
	            
	            listCart.add(new CartItem(idUser, idProduct, count));
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	    return listCart;
	}
}
