package controller;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import database.Connect;
import model.Promo;


public class PromoHandler {
	
	public boolean isPromo(String code) {
		String query = "SELECT * FROM promo WHERE code = ?";
        try {
            PreparedStatement ps = Connect.getInstance().prepareStatement(query);
            ps.setString(2, code);
            ResultSet rs = ps.executeQuery();
            
            return !rs.next(); 
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
	}
	
	public Promo getPromo(String code) {
		String query = "SELECT * FROM promo WHERE code = ?";
		Promo promo = null;
	    
	    try {
	        PreparedStatement ps = Connect.getInstance().prepareStatement(query);
	        ps.setString(1, code);
	        ResultSet rs = ps.executeQuery();
	        
	        if (rs.next()) {
	            String promoID = rs.getString("promoID");
	            String headline = rs.getString("headline");
	            Double discountPercentage = rs.getDouble("discountPercentage");
	            
	            promo = new Promo(promoID, code, headline, discountPercentage);
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	    return promo;
	}
	
		
}
